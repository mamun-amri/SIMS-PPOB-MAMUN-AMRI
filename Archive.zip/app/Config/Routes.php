<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Auth::index');

$routes->get('/auth', 'Auth::index');
$routes->get('/auth/regis', 'Auth::regis');
$routes->get('/auth/logout', 'Auth::logout');

$routes->post('/auth/save', 'Auth::save');
$routes->post('/auth/login', 'Auth::login');

$routes->get('/page', 'Page::index');
$routes->get('/page/topup', 'Page::topup');
$routes->post('/page/t_topup', 'Page::t_topup');

$routes->get('/page/service/(:any)', 'Page::service/$1');
$routes->post('/page/t_service', 'Page::t_service');

$routes->get('/page/transaksi', 'Page::transaksi');
$routes->post('/page/transaksi', 'Page::transaksi');

$routes->get('/page/akun', 'Page::akun');
$routes->post('/page/update', 'Page::update');
$routes->post('/page/update_image', 'Page::update_image');