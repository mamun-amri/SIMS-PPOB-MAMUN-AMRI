<?= $this->extend('template') ?>

<?= $this->section('content') ?>
<div class="m-3"></div>
<p>Pembayaran</p>
<h3><img src='<?=$service['service_icon']?>' alt='Icon' style="width:50px"> <?=$service['service_name']?></h3>
<?php 
    $session = session();
    if ($session->getflashdata('pesan')) {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                '.$session->getflashdata('pesan').'.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
        </div>';
    }
?>
<div class="row mt-5">
    <div class="col-md-12">
        
            <div class="form-group">
                <div class="input-group">
                <div class="input-group-prepend bg-transparent">
                    <span class="input-group-text bg-transparent border-right-0">
                    <i class="mdi mdi-newspaper text-primary"></i>
                    </span>
                </div>
                <input type="numeric" class="form-control form-control-lg border-left-0" onchange="setsaldo(this.value)" id="service_tariff" readonly name="service_tariff" value="<?= $service['service_tariff'] ?>">
                <?php if (isset($validation)): ?>
                    <div class="invalid-feedback text-left" style="display:<?= ($validation->hasError('service_tariff'))? 'block':'none' ?>">
                        <?= $validation->getError('service_tariff');?>
                    </div> 
                <?php endif?>
                </div>
            </div>
            <div class="my-3">
                <button class="btn btn-block btn-danger btn-lg font-weight-medium auth-form-btn" onclick="showbayar()" type="submit">Bayar</button>
            </div>
        
    </div>
</div>

<script>
    
    function showbayar() {
        // 
        var service_tariff = document.getElementById('service_tariff').value;
        Swal.fire({
        title: "Beli <?=$service['service_name']?> Senilai \n "+service_tariff,
        imageUrl: "<?=base_url('assets/app/logo.png')?>",
        imageWidth: 70,
        imageHeight: 70,
        showCancelButton: true,
        cancelButtonColor: "#3085d6",
        confirmButtonColor: "#d33",
        confirmButtonText: "Ya, lanjutkan bayar "
        }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '<?=base_url('page/t_service')?>',
                method: 'POST',
                data: {
                    service_code:"<?=$service['service_code']?>"
                },
                success: function(response) {
                    Swal.fire({
                        title: "pembayaran <?=$service['service_name']?> sebesar \n "+service_tariff,
                        text:'Berhasil',
                        icon: "success",
                        confirmButtonColor: "#d33",
                        confirmButtonText: "Kembali Ke Beranda",
                    }).then((result) => {
                        window.location.href = "<?=base_url('page')?>";
                    });
                }
            });
        }
        });
    }
    
</script>

<?= $this->endSection() ?>