<?= $this->extend('template_auth') ?>

<?= $this->section('content') ?>
        <h3 class="font-weight-light">Masuk atau buat akun <br>untuk memulai</h3>
        <?php 
        $session = session();
        if ($session->getflashdata('pesan')) {
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    '.$session->getflashdata('pesan').'.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
            </div>';
        }
        ?>
            <form class="pt-3" action="/auth/login" method="post">
                <div class="form-group">
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="mdi mdi-account-outline text-primary"></i>
                      </span>
                    </div>
                    <input type="email" class="form-control form-control-lg border-left-0" id="email" placeholder="masukan email anda" name="email" value="<?= $email ?>">
                    <?php if (isset($validation)): ?>
                    <div class="invalid-feedback text-left" style="display:<?= ($validation->hasError('email'))? 'block':'none' ?>">
                       <?= $validation->getError('email');?>
                    </div> 
                    <?php endif?>
                  </div>
                </div>
                <div class="form-group">
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="mdi mdi-lock-outline text-primary"></i>
                      </span>
                    </div>
                    <input type="password" class="form-control form-control-lg border-left-0" id="password" placeholder="masukan password anda" name="password">
                    <div class="input-group-prepend bg-transparent" onclick="togglePassword('password')">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="mdi mdi-eye-outline text-primary"></i>
                      </span>
                    </div>     
                    <?php if (isset($validation)): ?>
                    <div class="invalid-feedback text-left" style="display:<?= ($validation->hasError('password'))? 'block':'none' ?>">
                       <?= $validation->getError('password');?>
                    </div> 
                    <?php endif?>                   
                  </div>
                </div>
                <div class="my-3">
                  <button class="btn btn-block btn-danger btn-lg font-weight-medium auth-form-btn" type="submit">Masuk</button>
                </div>
                <div class="text-center mt-4 font-weight-light">
                  belum punya akun? Registrasi <a href="/auth/regis" class="text-danger">di sini</a>
                </div>
            </form>
<?= $this->endSection() ?>