<div class="row">
    <div class="col-lg-5">
        <div class="border-bottom text-center pb-4">
            <img src="<?=$profile_image?>" alt="profile" class="img-lg rounded-circle mb-3"/>
            <p class="d-flex justify-content-start">Selamat Datang</p>
            <h2 class="d-flex justify-content-start"><?=$fullname?></h2>

        </div>
    </div>
    <div class="col-lg-7">

        <div class="bg-saldo">
            <div class="p-3">
                <h6>Saldo Snda</h6>
                <h3>Rp <span id="saldo">********</span></h3>
                <p onclick="showsaldo()">Lihat Saldo</p>
                <input type="hidden" id="saldovalue" value="<?=$balance?>">
            </div>
        </div>
    </div>
</div>