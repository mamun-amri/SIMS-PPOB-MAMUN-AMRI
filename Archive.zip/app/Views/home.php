<?= $this->extend('template') ?>

<?= $this->section('profile') ?>
<?php include 'profile.php' ?>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="m-3"></div>
<div class="row">
    
    <?php 
    foreach ($services as $v) {
        echo "<div class='col-md-1 text-center'>
        <a href='".base_url('page/service/').$v['service_code']."'>
            <img src='$v[service_icon]' alt='Icon'>
        </a>
        <p style='font-size:10px'>$v[service_code]</p>
        </div>";
    }
    ?>
</div>

<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"> -->
<!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@splidejs/splide@3.6.12/dist/css/splide.min.css"> -->

<div class="container">
            <div class="row">
                <div class="splide">
                    <div class="splide__track">
                        <div class="splide__list">
                            <?php 
                            foreach ($banners as $v) :
                                if ($v['banner_image']) :
                            ?>
                            <div class="col-sm-3 splide__slide m-2">
                                <div class=" text-white">
                                    <div class="card-body">
                                        <img src="<?=$v['banner_image']?>" alt="">
                                    </div>
                                </div>
                            </div>
                            <?php endif; 
                        endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script> -->
        <!-- <script src="https://cdn.jsdelivr.net/npm/@splidejs/splide@3.6.12/dist/js/splide.min.js"></script> -->
        <!-- <script>
            var splide = new Splide('.splide', {
                type: 'loop',
                perPage: 3,
                rewind: true,
            });

            splide.mount();
        </script> -->
<?= $this->endSection() ?>