<?= $this->extend('template') ?>

<?= $this->section('profile') ?>
<?php include 'profile.php' ?>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="m-3"></div>
<p>Silahkan Masukan</p>
<h3>Nominal Top Up</h3>
<?php 
    $session = session();
    if ($session->getflashdata('pesan')) {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                '.$session->getflashdata('pesan').'.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
        </div>';
    }
?>
<div class="row">
    <div class="col-md-8">
        
            <div class="form-group">
                <div class="input-group">
                <div class="input-group-prepend bg-transparent">
                    <span class="input-group-text bg-transparent border-right-0">
                    <i class="mdi mdi-newspaper text-primary"></i>
                    </span>
                </div>
                <input type="numeric" class="form-control form-control-lg border-left-0" onchange="setsaldo(this.value)" id="top_up_amount" placeholder="masukan nominal Top Up" name="top_up_amount" value="<?= $top_up_amount ?>">
                <?php if (isset($validation)): ?>
                    <div class="invalid-feedback text-left" style="display:<?= ($validation->hasError('top_up_amount'))? 'block':'none' ?>">
                        <?= $validation->getError('top_up_amount');?>
                    </div> 
                <?php endif?>
                </div>
            </div>
            <div class="my-3">
                <button class="btn btn-block btn-danger btn-lg font-weight-medium auth-form-btn" id="btntopup" onclick="showtopup()" type="submit" disabled>Top Up</button>
            </div>
        
    </div>
    <div class="col-md-4">
        <div class="row">
            <div class="col-md-4">
                <label id="saldo10" onclick="pilihsaldo('10')" class="form-control form-control-lg" style="font-size:15px" >Rp10.000</label>
                <label id="saldo200" onclick="pilihsaldo('200')" class="form-control form-control-lg" style="font-size:15px" >Rp200.000</label>
            </div>
            
            <div class="col-md-4">
                <label id="saldo50" onclick="pilihsaldo('50')" class="form-control form-control-lg" style="font-size:15px" >Rp50.000</label>
                <label id="saldo250" onclick="pilihsaldo('250')" class="form-control form-control-lg" style="font-size:15px" >Rp250.000</label>
            </div>
            <div class="col-md-4">
                <label id="saldo100" onclick="pilihsaldo('100')" class="form-control form-control-lg" style="font-size:15px" >Rp100.000</label>
                <label id="saldo500" onclick="pilihsaldo('500')" class="form-control form-control-lg" style="font-size:15px" >Rp500.000</label>
            </div>
        </div>
    </div>
</div>

<script>
    function pilihsaldo(id) {
        var saldo = document.getElementById('saldo'+id).innerText;
        var top_up_amount = document.getElementById('top_up_amount');
        document.getElementById('btntopup').disabled = false;
        result = saldo.replace('Rp','');
        top_up_amount.value = result.replace('.','')
    }
    function setsaldo(saldo) {
        var top_up_amount = document.getElementById('top_up_amount');
        document.getElementById('btntopup').disabled = false;
        result = saldo.replace('Rp','');
        top_up_amount.value = result.replace('.','')
    }

    function showtopup() {
        // 
        var top_up_amount = document.getElementById('top_up_amount').value;
        Swal.fire({
        title: "anda yakin untuk topup sebesar \n "+top_up_amount,
        imageUrl: "<?=base_url('assets/app/logo.png')?>",
        imageWidth: 70,
        imageHeight: 70,
        showCancelButton: true,
        cancelButtonColor: "#3085d6",
        confirmButtonColor: "#d33",
        confirmButtonText: "Ya, lanjutkan bayar "
        }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '<?=base_url('page/t_topup')?>',
                method: 'POST',
                data: {
                    top_up_amount:top_up_amount
                },
                success: function(response) {
                    Swal.fire({
                        title: "topup sebesar \n "+top_up_amount,
                        text:'Berhasil',
                        icon: "success",
                        confirmButtonColor: "#d33",
                        confirmButtonText: "Kembali Ke Beranda"
                    }).then((result) => {
                        window.location.href = "<?=base_url('page/topup')?>";
                    });
                }
            });
        }
        });
    }
    
</script>

<?= $this->endSection() ?>