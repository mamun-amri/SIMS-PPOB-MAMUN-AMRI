<?= $this->extend('template') ?>

<?= $this->section('profile') ?>
<?php include 'profile.php' ?>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="m-3"></div>
<p>Semua transaksi</p>
<?php 
    $session = session();
    if ($session->getflashdata('pesan')) {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                '.$session->getflashdata('pesan').'.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
        </div>';
    }
?>
<div class="row mt-5">
    <div class="col-md-12">
        <div id="dragula-event-left" class="py-2">
                <?php 
                    foreach ($histories as $key =>$value):
                        if ($key=='records') :
                            foreach ($value as $k => $v) :
                                $icon='minus';
                                $color='danger';
                                if ($v['transaction_type']=='TOPUP') {
                                    $icon='plus';
                                    $color='success';
                                }
                                $dateTime = new DateTime($v['created_on']);
                                $tgl = $dateTime->format('d-M-Y');
                                $wkt = $dateTime->format('H:i:s').' WIB';
                                ?>
                                <div class="card rounded border mb-2">
                                    <div class="card-body p-3">
                                        <div class="media">
                                            <i class="mdi mdi-<?=$icon?> icon-sm text-<?=$color?> align-self-center mr-3"></i>
                                            <div class="media-body">
                                                <h6 class="h5 mb-1"><?=$v['total_amount']?> <span class="h6 text-muted float-right justify-content-end"> <?=$v['description']?></span></h6>
                                                <p class="mb-0 text-muted">
                                                    <?= $tgl . ' '. $wkt?>                               
                                                </p>
                                            </div>                              
                                        </div> 
                                    </div>
                                </div>
                    <?php 
                            endforeach;
                        ;else:
                            if ($key=='offset') {
                                $offset = $value;
                            }
                            if ($key=='limit') {
                                $limit = $value;
                            }
                        endif;
                    endforeach; ?>
                    <!-- load more data -->
                    <form action="/page/transaksi" method="post">

                        <input type='hidden' name='offset' id='offset' value='<?=$offset?>'>
                        <input type='hidden' name='limit' id='limit' value='<?=$limit?>'>
                        <input type='hidden' name='next' id='next' value='<?=$limit?>'>
                        <div class="my-3 d-flex justify-content-center">
                            <button class=" btn text-danger font-weight-medium" type="submit" >Show More</button>
                        </div>
                    </form>
        </div>
    </div>
</div>

<?= $this->endSection() ?>