<?= $this->extend('template') ?>

<?= $this->section('content') ?>
        <?php 
        $session = session();
        if ($session->getflashdata('pesan')) {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    '.$session->getflashdata('pesan').'.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
            </div>';
        }
        ?> 
            <div class="border-bottom text-center pb-4">
              <?php 
                if (substr_count($profile_image,'null')) {
                  $img = base_url('assets/app/Profile Photo.png');
                }else{
                  $img = $profile_image;
                }
              ?>
              
              <div class="d-flex justify-content-center">
                <img src="<?=$img?>" alt="profile" id="profile" class="img-lg rounded-circle mb-3"/>
                <div class="file-upload-wrapper" onclick="document.getElementById('file-input').click();">
                    <i class="mdi mdi-border-color text-black" style="font-size: 20px"></i>
                    <input type="file" id="file-input" name="image" class="file-input" onchange="update(this)"/>
                </div>

                </div>
                  <h3><?=$fullname?></h3>
                </div>
              
              <form class="pt-3" action="/page/update" method="post" >
                <div class="form-group">
                  <label for="email">Email</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="mdi mdi-email-outline text-primary"></i>
                      </span>
                    </div>
                    <input type="email" readonly class="form-control form-control-lg border-left-0" id="email" name="email" placeholder="masukan email anda" value="<?= $email ?>">
                    <?php if (isset($validation)): ?>
                    <div class="invalid-feedback text-left" style="display:<?= ($validation->hasError('email'))? 'block':'none' ?>">
                       <?= $validation->getError('email');?>
                    </div> 
                    <?php endif;?>
                  </div>
                </div>
                <div class="form-group">
                  <label for="first_name">Nama Depan</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="mdi mdi-account-outline text-primary"></i>
                      </span>
                    </div>
                    <input type="text" class="form-control form-control-lg border-left-0" id="first_name" name="first_name" placeholder="nama depan" value="<?= $first_name ?>">
                  <?php if (isset($validation)): ?>
                    <div class="invalid-feedback text-left" style="display:<?= ($validation->hasError('first_name'))? 'block':'none' ?>">
                       <?= $validation->getError('first_name');?>
                    </div> 
                  <?php endif;?>
                  </div>
                </div>
                <div class="form-group">
                  <label for="last_name">Nama Belakang</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="mdi mdi-account-outline text-primary"></i>
                      </span>
                    </div>
                    <input type="text" class="form-control form-control-lg border-left-0" id="last_name" name="last_name" placeholder="nama belakang" value="<?= $last_name ?>">
                    <?php if (isset($validation)): ?>
                    <div class="invalid-feedback text-left" style="display:<?= ($validation->hasError('last_name'))? 'block':'none' ?>">
                       <?= $validation->getError('last_name');?>
                    </div> 
                    <?php endif?>
                  </div>
                </div>
                
                <div class="my-3">
                  <button class="btn btn-block btn-danger btn-lg font-weight-medium auth-form-btn" type="submit" id="btnsimpan" >Simpan</button>
                  </div>
                </form>
                <a href="<?=base_url('page/akun')?>" class="btn btn-block btn-outline-danger btn-lg font-weight-medium auth-form-btn" id="btnbatal" >Batal</a>
                  </div>
                <div id="divedit">
                  <button class="btn btn-block btn-outline-danger btn-lg font-weight-medium auth-form-btn" onclick="showdiv()">Edit Profile</button>
                  <div class="my-3">
                    <a href="/auth/logout"> <button class="btn btn-block btn-danger btn-lg font-weight-medium auth-form-btn" >Log Out</button></a>
                  </div>
                </div>
                <script src="<?=base_url('assets/')?>js/jquery-3.6.0.min.js"></script>
            <script>
             
              $('#btnsimpan').hide();
              $('#btnbatal').hide();
              $('#divedit').show();

              function showdiv() {
                $('#divedit').hide();
                $('#btnsimpan').show();
                $('#btnbatal').show();
              }

              function bytesToKB(bytes) {
                  return (bytes / 1024).toFixed(0);
              }
              
              function update(r) {
                var file = document.getElementById('file-input').files[0]; 
                var formData = new FormData();
                formData.append('file', file);
                size = bytesToKB(r.files[0]['size']);
                if (size <=100) {
                  // Buat objek XMLHttpRequest
                  var xhr = new XMLHttpRequest();

                  // Set endpoint URL dan jenis request
                  var url = 'https://take-home-test-api.nutech-integrasi.app/profile/image';
                  xhr.open('PUT', url, true);

                  // Atur header untuk menerima respons dalam format JSON dan autentikasi
                  xhr.setRequestHeader('accept', 'application/json');
                  xhr.setRequestHeader('Authorization', 'Bearer <?=$session->get('token')?>'); 
                  // Ketika permintaan selesai
                  xhr.onload = function() {
                      if (xhr.status === 0) {
                          Swal.fire({
                            title: "Upload Profile",
                            text:'Berhasil',
                            icon: "success",
                            confirmButtonColor: "#d33",
                            confirmButtonText: "OK"
                        });
                      } else {
                          console.error('Terjadi kesalahan saat mengunggah file');
                      }
                  };
                  xhr.send(formData);
                }else{
                  Swal.fire({
                        title: "Ukuran File Maksimum \n 100KB",
                        icon: "warning",
                        confirmButtonColor: "#d33",
                        confirmButtonText: "OK"
                    });
                }

              }
            </script>
<?= $this->endSection() ?>