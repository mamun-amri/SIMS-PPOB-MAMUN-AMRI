<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?= $title ?></title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?=base_url('assets/')?>vendors/flag-icon-css/css/flag-icon.min.css">
  <link rel="stylesheet" href="<?=base_url('assets/')?>vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="<?=base_url('assets/')?>vendors/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?=base_url('assets/')?>vendors/simple-line-icons/css/simple-line-icons.css">
  <link rel="stylesheet" href="<?=base_url('assets/')?>vendors/feather/feather.css">
  <link rel="stylesheet" href="<?=base_url('assets/')?>vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="<?=base_url('assets/')?>vendors/owl-carousel-2/owl.carousel.min.css">
  <link rel="stylesheet" href="<?=base_url('assets/')?>vendors/owl-carousel-2/owl.theme.default.min.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?=base_url('assets/')?>css/horizontal-layout/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?=base_url('assets/')?>images/favicon.png" />
  <style>
      .bg-saldo {
      background-image: url('<?=base_url('assets/app/Background Saldo.png')?>'); /* Ganti dengan path lokasi gambar Anda */
      background-size: cover;
      background-position: center center;
      color: white; 
      height: 120px;
      border-radius:10px;
      }
      
    .file-upload-wrapper {
        border: 2px dashed #ccc;
        padding: 5px;
        text-align: center;
        cursor: pointer;
        border-radius:100px;
        width:35px;
        height:35px;
        position: absolute;
        margin-top: 50px;
        margin-left: 90px;
    }

    .file-upload-wrapper:hover {
        background-color: #f9f9f9;
    }

    .file-input {
        display: none;
    }
</style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@splidejs/splide@3.6.12/dist/css/splide.min.css">
    <script src="<?=base_url('assets/')?>js/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.0/dist/sweetalert2.all.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.0/dist/sweetalert2.min.css" rel="stylesheet">
</head>

<body>
<div class="container-scroller">
    <!-- partial:../../partials/_horizontal-navbar.html -->
    <div class="horizontal-menu">
        <nav class="bottom-navbar">
            <div class="container">
                <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end flex-grow-1">
                    <ul class="navbar-nav navbar-nav-right">
                        <li class="nav-item">
                        <a class="navbar-brand brand-logo" href="/page">
                            <img src="<?=base_url('assets/app/')?>logo.png" alt="logo"/>
                            <span class="menu-title text-black"><?=$appname?></span>
                        </a>
                        </li>
                    </ul>
                    <ul  class="nav page-navigation justify-content-end">   
                        <li class="pt-3 pb-3 mr-4">
                        <a class="nav-link " href="/page/topup">
                            <span class="menu-title <?=($title=='topup')?'text-danger':'text-black'?>" >Top Up</span>
                        </a>
                        </li>
                        <li class="pt-3 pb-3 mr-4">
                        <a class="nav-link" href="/page/transaksi">
                            <span class="menu-title <?=($title=='transaksi')?'text-danger':'text-black'?>">Transaction</span>
                        </a>
                        </li>
                        <li class="pt-3 pb-3 ">
                        <a class="nav-link" href="/page/akun">
                            <span class="menu-title <?=($title=='akun')?'text-danger':'text-black'?>">Akun</span>
                        </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    
                                <?= $this->renderSection('profile') ?>
                                <?= $this->renderSection('content') ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
      <!-- main-panel ends -->
        </div>
    <!-- page-body-wrapper ends -->
    </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="<?=base_url('assets/')?>vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?=base_url('assets/')?>js/off-canvas.js"></script>
  <script src="<?=base_url('assets/')?>js/hoverable-collapse.js"></script>
  <script src="<?=base_url('assets/')?>js/template.js"></script>
  <script src="<?=base_url('assets/')?>js/settings.js"></script>
  <script src="<?=base_url('assets/')?>js/todolist.js"></script>
  <script src="<?=base_url('assets/')?>vendors/owl-carousel-2/owl.carousel.min.js"></script>
  <!-- End plugin js for this page -->
  <!-- Custom js for this page-->
  <script src="<?=base_url('assets/')?>js/owl-carousel.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?=base_url('assets/')?>js/profile-demo.js"></script>
  <script>
    function showsaldo() {
        var saldo = document.getElementById('saldo');
        var saldovalue = document.getElementById('saldovalue').value.toLocaleString();

        if (saldo.innerText === "********") {
            saldo.innerText = saldovalue;
        } else {
            saldo.innerText = "********";
        }
    }
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@splidejs/splide@3.6.12/dist/js/splide.min.js"></script>
    <script>
        var splide = new Splide('.splide', {
            type: 'loop',
            perPage: 3,
            rewind: true,
        });

        splide.mount();
    </script>
  <!-- End custom js for this page-->

  
</body>

</html>