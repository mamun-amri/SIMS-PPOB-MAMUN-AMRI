<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    // public function __construct()
    // {
    //     $session = session();
    //     if ($session->has('token')) {
    //         redirect()->to('/page'); // Redirect ke halaman login jika sesi tidak ada
    //     }
        
    // }
    public function index()
    {
        $data = [
            'title' => 'Login',
            'appname'=>'SIMS PPOB-MA\'MUN AMRI',
            'email' => ''
        ];
        
        return view('login', $data);
        
    }

    public function login()
    {
        $session = session();   
        $validationRules = [
            'email' => 'required|valid_email',
            'password' => 'required|min_length[8]'
        ];
        $validationMessages = [
            'email' => [
                'valid_email' => 'Email tidak sesuai'
            ]
            ];
        if (!$this->validate($validationRules, $validationMessages)) {
            $data = [
                'title' => 'Login',
                'appname'=>'SIMS PPOB-MA\'MUN AMRI',
                'validation' => $this->validator,
                'email' => $this->request->getVar('email')
            ];
            
            return view('login', $data);
        }else{
            $url = 'https://take-home-test-api.nutech-integrasi.app/login';
            $datas = [
                'email' => $this->request->getVar('email'),
                'password' => $this->request->getVar('password'),
            ];
            $postData = json_encode($datas);
            $json = $this->postCurl($url, $postData);
            
            if ($json['status'] !=0 ) {
                $session->setFlashdata('pesan', $json['message']);
                $data = [
                    'title' => 'Login',
                    'appname'=>'SIMS PPOB-MA\'MUN AMRI',
                    'validation' => $this->validator,
                    'email' => $this->request->getVar('email')
                ];
            
                return view('login', $data);
            } else {
                $token = $json['data']['token'];
                $session->set('token', $token);
                // echo $token;
                return redirect()->to('/page');
            }
    
        }
    }


    public function regis()
    {
        $data = [
            'title' => 'Registrasi',
            'appname'=>'SIMS PPOB-MA\'MUN AMRI',
            'email' => '',
            'first_name' => '',
            'last_name' => '',
            'password' => ''
        ];
        return view('regis', $data);
    }

    public function save()
    {        
        $session = session();
        // Validasi input dari form
        $validationRules = [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|valid_email',
            'password' => 'required|min_length[8]',
            'password2' => 'required|min_length[8]|matches[password]'
        ];
        $validationMessages = [
            'email' => [
                'valid_email' => 'Email tidak sesuai'
            ],
            'password2' => [
                'matches' => 'password tidak sama'
            ],
            'password2' => [
                'min_length' => 'panjang karakter minimal 8'
            ],
            'password' => [
                'min_length' => 'panjang karakter minimal 8'
            ],
        ];
        if (!$this->validate($validationRules, $validationMessages)) {
            $data = [
                'title' => 'Registrasi',
                'appname'=>'SIMS PPOB-MA\'MUN AMRI',
                'validation' => $this->validator,
                'email' => $this->request->getVar('email'),
                'first_name' => $this->request->getVar('first_name'),
                'last_name' => $this->request->getVar('last_name'),
                'password' => $this->request->getVar('password')
            ];
            return view('regis', $data);
        }else{

            $url = 'https://take-home-test-api.nutech-integrasi.app/registration';
            $datas = [
                'email' => $this->request->getVar('email'),
                'first_name' => $this->request->getVar('first_name'),
                'last_name' => $this->request->getVar('last_name'),
                'password' => $this->request->getVar('password'),
            ];
            $postData = json_encode($datas);
            $json =$this->postCurl($url, $postData);
            
            
            // Tangani respons atau error
            if ($json['status'] != 0) {
                $session->setFlashdata('pesan', $json['message']);
                $data = [
                    'title' => 'Registrasi',
                    'appname'=>'SIMS PPOB-MA\'MUN AMRI',
                    'validation' => $this->validator,
                    'email' => $this->request->getVar('email'),
                    'first_name' => $this->request->getVar('first_name'),
                    'last_name' => $this->request->getVar('last_name'),
                    'password' => $this->request->getVar('password')
                ];
                return view('regis', $data);
            } else {
                $session->setFlashdata('pesan', 'Registrasi berhasil! Silakan login.');
                return redirect()->to('/auth');
            }
    
        }
    }

    public function postCurl($url,$data)
    {
        $curl = curl_init($url);
            // Set options untuk cURL
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

        // Eksekusi cURL untuk mendapatkan respons
        $response = curl_exec($curl);
        return json_decode($response, true);
    }

    public function logout()
    {
        $session = session();
        $session->remove('token');
        return redirect()->to('/auth');
    }
}
