<?php

namespace App\Controllers;

class Page extends BaseController
{
    public function __construct()
    {
        $session = session();
        $token = $session->get('token');
        if ($token==null) {
            return redirect()->to('/auth');
        }
    }

    public function index()
    {
        $url = 'https://take-home-test-api.nutech-integrasi.app/';
        
        $json =$this->getCurl($url.'profile'); 
        $banners =$this->getCurl($url.'banner'); 
        $services =$this->getCurl($url.'services'); 
        $balance =$this->getCurl($url.'balance'); 
        $data = [
            'title' => 'Home',
            'appname'=>'SIMS PPOB-MA\'MUN AMRI',
            'profile_image'=>$json['data']['profile_image'],
            'fullname'=>$json['data']['first_name'] .' '.$json['data']['last_name'],
            'banners'=>$banners['data'],
            'services'=>$services['data'],
            'balance'=>$balance['data']['balance'],
        ];
        return view('home', $data);
    }

    public function topup()
    {
        $url = 'https://take-home-test-api.nutech-integrasi.app/';
        
        $json =$this->getCurl($url.'profile'); 
        $banners =$this->getCurl($url.'banner'); 
        $services =$this->getCurl($url.'services'); 
        $balance =$this->getCurl($url.'balance'); 
        $data = [
            'title' => 'topup',
            'appname'=>'SIMS PPOB-MA\'MUN AMRI',
            'profile_image'=>$json['data']['profile_image'],
            'fullname'=>$json['data']['first_name'] .' '.$json['data']['last_name'],
            'balance'=>$balance['data']['balance'],
            'top_up_amount'=>'',
        ];
        return view('topup', $data);
    }

    public function t_topup()
    {        
        $session = session();
        $validationRules = [
            'top_up_amount' => 'required|greater_than_equal_to[10000]|less_than_equal_to[1000000]',
        ];
        $validationMessages = [
            'top_up_amount' => [
                'greater_than_equal_to' => 'Minimal 10.000',
                'less_than_equal_to' => 'Maksimal 1.000.000',
            ],
        ];
        if (!$this->validate($validationRules, $validationMessages)) {
            $url = 'https://take-home-test-api.nutech-integrasi.app/';
            $json =$this->getCurl($url.'profile'); 
            $banners =$this->getCurl($url.'banner'); 
            $services =$this->getCurl($url.'services'); 
            $balance =$this->getCurl($url.'balance'); 
            $data = [
                'title' => 'topup',
                'appname'=>'SIMS PPOB-MA\'MUN AMRI',
                'profile_image'=>$json['data']['profile_image'],
                'validation' => $this->validator,
                'fullname'=>$json['data']['first_name'] .' '.$json['data']['last_name'],
                'balance'=>$balance['data']['balance'],
                'top_up_amount' => $this->request->getVar('top_up_amount')
            ];
            return view('topup', $data);
        }else{

            $url = 'https://take-home-test-api.nutech-integrasi.app/topup';
            $datas = [
                'top_up_amount' => $this->request->getVar('top_up_amount'),
            ];
            $postData = json_encode($datas);
            $json =$this->postCurl($url, $postData);
            // Tangani respons atau error
            if ($json['status'] != 0) {
                $session->setFlashdata('pesan', $json['message']);
                $this->topup();
            } else {
                $session->setFlashdata('pesan', $json['message']);
                return redirect()->to('/page/topup');
            }
    
        }
    }

    public function service($id)
    {
        $url = 'https://take-home-test-api.nutech-integrasi.app/';
        
        $json =$this->getCurl($url.'profile'); 
        $banners =$this->getCurl($url.'banner'); 
        $services =$this->getCurl($url.'services'); 
        $balance =$this->getCurl($url.'balance'); 
        foreach ($services['data'] as $k => $v) {
            if ($v['service_code']==$id) {
                $service = $v;
            }
        }
        
        $data = [
            'title' => 'service',
            'appname'=>'SIMS PPOB-MA\'MUN AMRI',
            'profile_image'=>$json['data']['profile_image'],
            'fullname'=>$json['data']['first_name'] .' '.$json['data']['last_name'],
            'balance'=>$balance['data']['balance'],
            'service'=>$service,
        ];
        return view('service', $data);
    }

     public function t_service()
    {        
        $session = session();
        
        if (!$this->request->getVar('service_code')) {
            $this->service($this->request->getVar('service_code'));
        }else{

            $url = 'https://take-home-test-api.nutech-integrasi.app/transaction';
            $datas = [
                'service_code' => $this->request->getVar('service_code'),
            ];
            $postData = json_encode($datas);
            $json =$this->postCurl($url, $postData);
            // Tangani respons atau error
            if ($json['status'] != 0) {
                $session->setFlashdata('pesan', $json['message']);
                $this->topup();
            } else {
                $session->setFlashdata('pesan', $json['message']);
                return redirect()->to('/page');
            }
    
        }
    }

    public function transaksi()
    {
        $url = 'https://take-home-test-api.nutech-integrasi.app/';

        $next = $this->request->getVar('next');
        $offset = $this->request->getVar('offset');
        $limit = $this->request->getVar('limit');
        if ($next>0) {
            $offset += $limit; 
            $oflim ='offset='.$offset.'&limit='.$limit;
        }else{
            $oflim ='offset=0&limit=5';
        }

        $json =$this->getCurl($url.'profile'); 
        $banners =$this->getCurl($url.'banner'); 
        $services =$this->getCurl($url.'services'); 
        $balance =$this->getCurl($url.'balance'); 
        $histories =$this->getCurl($url.'transaction/history?'.$oflim); 
        $data = [
            'title' => 'transaksi',
            'appname'=>'SIMS PPOB-MA\'MUN AMRI',
            'profile_image'=>$json['data']['profile_image'],
            'fullname'=>$json['data']['first_name'] .' '.$json['data']['last_name'],
            'balance'=>$balance['data']['balance'],
            'histories'=>$histories['data'],
        ];
        return view('transaksi', $data);
    }

    public function akun()
    {
        $url = 'https://take-home-test-api.nutech-integrasi.app/';
        
        $json =$this->getCurl($url.'profile'); 
        $banners =$this->getCurl($url.'banner'); 
        $services =$this->getCurl($url.'services'); 
        $balance =$this->getCurl($url.'balance'); 
        $data = [
            'title' => 'akun',
            'appname'=>'SIMS PPOB-MA\'MUN AMRI',
            'profile_image'=>$json['data']['profile_image'],
            'email'=>$json['data']['email'],
            'fullname'=>$json['data']['first_name'] .' '.$json['data']['last_name'],
            'first_name'=>$json['data']['first_name'],
            'last_name'=>$json['data']['last_name'],
            'banners'=>$banners['data'],
            'services'=>$services['data'],
            'balance'=>$balance['data']['balance'],
        ];
        return view('akun', $data);
    }

    public function update()
    {        
        $session = session();
        // Validasi input dari form
        $validationRules = [
            'first_name' => 'required',
            'last_name' => 'required'
        ];
        $validationMessages = [
            
        ];
        if (!$this->validate($validationRules, $validationMessages)) {
            $url = 'https://take-home-test-api.nutech-integrasi.app/';
            $json =$this->getCurl($url.'profile'); 
            $data = [
                'title' => 'Update',
                'appname'=>'SIMS PPOB-MA\'MUN AMRI',
                'fullname'=>$json['data']['first_name'] .' '.$json['data']['last_name'],
                'validation' => $this->validator,
                'email' => $this->request->getVar('email'),
                'first_name' => $this->request->getVar('first_name'),
                'last_name' => $this->request->getVar('last_name')
            ];
            return view('akun', $data);
        }else{
            $url = 'https://take-home-test-api.nutech-integrasi.app/profile/update';
            $datas = [
                'first_name' => $this->request->getVar('first_name'),
                'last_name' => $this->request->getVar('last_name'),
            ];
            $postData = json_encode($datas);
            $json =$this->putCurl($url, $postData);
            
            print_r($json);
            // Tangani respons atau error
            if ($json['status'] != 0) {
                $session->setFlashdata('pesan', $json['message']);
                $this->akun();
            } else {
                $session->setFlashdata('pesan', 'Registrasi berhasil! Silakan login.');
                return redirect()->to('/page/akun');
            }
    
        }
    }

    public function getCurl($url)
    { 
        $session = session();
        $token = $session->get('token');
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        'accept: application/json',
        'Authorization: Bearer ' . $token,
        ));
        $result = curl_exec($curl);
        // curl_close($curl);

        return json_decode($result, true);
    }

    public function postCurl($url,$data)
    {
        $session = session();
        $token = $session->get('token');
        $curl = curl_init($url);
            // Set options untuk cURL
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json','Authorization: Bearer ' . $token,]);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

        $response = curl_exec($curl);
        return json_decode($response, true);
    }

    public function putCurl($url,$data)
    {
        $session = session();
        $token = $session->get('token');
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT');
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'accept: application/json',
            'Authorization: Bearer ' . $token // Menambahkan header Authorization dengan token
        ]);
        
        $result = curl_exec($curl);
        return json_decode($result, true);
    }
    
}
